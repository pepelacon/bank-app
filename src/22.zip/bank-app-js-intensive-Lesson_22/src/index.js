import '@/styles/global.scss'

import { Router } from './core/router/router'

new Router()
